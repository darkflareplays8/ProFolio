#version 150

uniform vec4 ColorModulator;
uniform float GameTime;

in vec4 vertexColor;
in vec2 screenPos;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor * ColorModulator;

    float time = GameTime * 1200.0;
    float skyShift = sin(time * 0.004) * 0.03;
    color.b = clamp(color.b + skyShift, 0.0, 1.0);
    color.r = clamp(color.r + skyShift * 0.3, 0.0, 1.0);

    fragColor = color;
}
