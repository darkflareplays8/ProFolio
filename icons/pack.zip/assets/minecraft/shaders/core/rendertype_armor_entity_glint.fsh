#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float GlintAlpha;
uniform float GameTime;

in vec2 texCoord0;
in vec2 texCoord1;

out vec4 fragColor;

void main() {
    vec4 t0 = texture(Sampler0, texCoord0);
    vec4 t1 = texture(Sampler0, texCoord1);

    float time = GameTime * 1200.0;

    vec3 glint0 = t0.rgb * vec3(0.55, 0.3, 1.0);
    vec3 glint1 = t1.rgb * vec3(0.3, 0.6, 1.0);

    vec3 combined = glint0 + glint1;

    float shimmer = sin(time * 3.0 + texCoord0.x * 15.0 + texCoord0.y * 15.0) * 0.15 + 0.85;
    combined *= shimmer;

    combined *= ColorModulator.rgb;

    fragColor = vec4(combined * GlintAlpha, (t0.a + t1.a) * 0.5 * GlintAlpha);
}
