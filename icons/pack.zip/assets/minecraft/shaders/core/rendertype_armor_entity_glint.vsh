#version 150

in vec3 Position;
in vec2 UV0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform float GameTime;

out vec2 texCoord0;
out vec2 texCoord1;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    float time = GameTime * 8.0;
    texCoord0 = UV0 * 4.0 + vec2(time * 0.7, time * 0.4);
    texCoord1 = UV0 * 4.0 + vec2(-time * 0.3, time * 0.6);
}
