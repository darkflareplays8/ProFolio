#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.01) discard;

    float time = GameTime * 1200.0;

    float ring = sin(texCoord0.y * 30.0 - time * 2.5) * 0.08 + 0.92;
    float twist = sin(texCoord0.x * 20.0 + time * 1.5) * 0.06 + 0.94;
    color.rgb *= ring * twist;

    color.rgb = clamp(color.rgb * 1.5, 0.0, 2.0);

    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
