#version 150

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;
uniform vec4 ColorModulator;
uniform float GameTime;

in vec3 worldPos;

out vec4 fragColor;

void main() {
    float time = GameTime * 1200.0;
    vec2 uv = worldPos.xz * 0.04;

    vec3 color = vec3(0.0);
    float scale = 1.0;
    for (int i = 0; i < 8; i++) {
        float fi = float(i);
        vec2 offset = vec2(sin(time * 0.003 + fi * 1.3), cos(time * 0.002 + fi * 0.9));
        vec3 layer = texture(Sampler0, uv * scale + offset * 0.05).rgb;
        vec3 tint = mix(
            vec3(0.05, 0.0, 0.15),
            vec3(0.0, 0.25, 0.4),
            fi / 7.0
        );
        color += layer * tint / (fi + 1.0);
        scale *= 1.5;
    }

    float shimmer = sin(time * 4.0 + worldPos.x * 10.0 + worldPos.z * 10.0) * 0.05 + 0.95;
    color *= shimmer * 2.5;

    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0) * ColorModulator;
}
