#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;

out vec4 fragColor;

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 saturateColor(vec3 c, float a) { return mix(vec3(luma(c)), c, a); }

void main() {
    vec4 texColor = texture(Sampler0, texCoord0);
    if (texColor.a < 0.02) discard;

    vec4 color = texColor * vertexColor * ColorModulator;
    vec3 lit = color.rgb * lightMapColor.rgb;
    lit = mix(lit, overlayColor.rgb, overlayColor.a);
    lit = saturateColor(lit, 1.2);

    float time = GameTime * 1200.0;
    float shimmer = sin(time * 2.0 + texCoord0.x * 30.0) * 0.04 + 0.96;
    lit *= shimmer;

    fragColor = linear_fog(vec4(lit, color.a * 0.85), vertexDistance, FogStart, FogEnd, FogColor);
}
