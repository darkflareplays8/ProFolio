#version 150

uniform vec4 ColorModulator;
uniform float GameTime;

in vec4 vertexColor;

out vec4 fragColor;

void main() {
    fragColor = vertexColor * ColorModulator;
}
