#version 150

uniform vec4 ColorModulator;
uniform float GameTime;

in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor * ColorModulator;
    float time = GameTime * 1200.0;
    float flicker = sin(time * 25.0) * 0.15 + 0.85;
    color.rgb *= flicker;
    color.rgb = mix(color.rgb, vec3(0.8, 0.9, 1.0), 0.3);
    fragColor = color;
}
