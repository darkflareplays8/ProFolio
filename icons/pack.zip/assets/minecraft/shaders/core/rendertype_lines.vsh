#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec3 Normal;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform mat3 IViewRotMat;
uniform float LineWidth;
uniform vec2 ScreenSize;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;

void main() {
    vec4 linePosStart = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vec4 linePosEnd = ProjMat * ModelViewMat * vec4(Position + Normal, 1.0);

    vec2 startNDC = linePosStart.xy / linePosStart.w;
    vec2 endNDC = linePosEnd.xy / linePosEnd.w;
    vec2 lineDir = normalize((endNDC - startNDC) * ScreenSize);
    vec2 normalDir = vec2(-lineDir.y, lineDir.x);

    float aspect = ScreenSize.y / ScreenSize.x;
    vec2 offset = normalDir * LineWidth / ScreenSize;
    gl_Position = vec4(linePosStart.xy + vec2(offset.x, offset.y * aspect) * linePosStart.w, linePosStart.zw);

    vertexDistance = fog_distance(ModelViewMat, IViewRotMat, Position, FogShape);
    vertexColor = Color;
}
