#version 150

#moj_import <fog.glsl>

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;

in float vertexDistance;
in vec4 vertexColor;
in vec3 worldPos;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor * ColorModulator;

    float time = GameTime * 1200.0;
    float dayPhase = sin(time * 0.004) * 0.5 + 0.5;

    color.b = clamp(color.b + dayPhase * 0.04, 0.0, 1.0);
    color.r = clamp(color.r - dayPhase * 0.01, 0.0, 1.0);

    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
