#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;
in vec4 normal;

out vec4 fragColor;

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

vec3 saturateColor(vec3 c, float a) {
    return mix(vec3(luma(c)), c, a);
}

vec3 contrastColor(vec3 c, float a) {
    return clamp((c - 0.5) * a + 0.5, 0.0, 1.0);
}

void main() {
    vec4 texColor = texture(Sampler0, texCoord0);
    if (texColor.a < 0.1) discard;

    vec4 color = texColor * vertexColor * ColorModulator;

    vec3 lit = color.rgb * lightMapColor.rgb;

    lit = contrastColor(lit, 1.10);
    lit = saturateColor(lit, 1.20);
    lit.r *= 1.02;
    lit.b *= 1.04;

    float time = GameTime * 1200.0;
    float shimmer = sin(time + texCoord0.x * 40.0 + texCoord0.y * 40.0) * 0.012 + 0.988;
    lit *= shimmer;

    fragColor = linear_fog(vec4(lit, color.a), vertexDistance, FogStart, FogEnd, FogColor);
}
