#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float GameTime;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 texColor = texture(Sampler0, texCoord0);
    if (texColor.a < 0.1) discard;

    vec4 color = texColor * vertexColor * ColorModulator;

    color.rgb = clamp(color.rgb * 1.15, 0.0, 1.0);

    fragColor = color;
}
