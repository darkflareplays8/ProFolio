#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec2 texCoord0;

out vec4 fragColor;

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 saturateColor(vec3 c, float a) { return mix(vec3(luma(c)), c, a); }

void main() {
    vec4 texColor = texture(Sampler0, texCoord0);
    if (texColor.a < 0.02) discard;

    vec4 color = texColor * vertexColor * ColorModulator;
    vec3 lit = color.rgb * lightMapColor.rgb;

    float time = GameTime * 1200.0;

    vec2 rippleUV = texCoord0 * 30.0;
    float ripple = sin(rippleUV.x + time * 1.4) * sin(rippleUV.y + time * 0.9) * 0.018;
    lit += vec3(ripple * 0.6, ripple * 0.8, ripple * 1.2);

    float fresnel = 0.04 + 0.96 * pow(1.0 - abs(dot(normalize(vec3(0.0, 1.0, 0.5)), vec3(0.0, 1.0, 0.0))), 3.0);
    lit = mix(lit, lit * 1.3 + vec3(0.02, 0.04, 0.08), fresnel * 0.4);

    lit = saturateColor(lit, 1.35);

    lit.b = clamp(lit.b * 1.08, 0.0, 1.0);

    fragColor = linear_fog(vec4(lit, color.a * 0.88), vertexDistance, FogStart, FogEnd, FogColor);
}
