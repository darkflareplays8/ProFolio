float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

vec3 spark_saturate(vec3 c, float a) {
    return mix(vec3(luma(c)), c, a);
}

vec3 spark_contrast(vec3 c, float a) {
    return clamp((c - 0.5) * a + 0.5, 0.0, 1.0);
}

vec3 spark_grade(vec3 c) {
    c = spark_contrast(c, 1.10);
    c = spark_saturate(c, 1.20);
    c.r *= 1.02;
    c.b *= 1.04;
    return c;
}

vec3 spark_water(vec3 c, vec2 uv, float time) {
    vec2 rippleUV = uv * 30.0;
    float ripple = sin(rippleUV.x + time * 1.4) * sin(rippleUV.y + time * 0.9) * 0.018;
    c += vec3(ripple * 0.6, ripple * 0.8, ripple * 1.2);
    c.b = clamp(c.b * 1.08, 0.0, 1.0);
    return spark_saturate(c, 1.35);
}

float spark_shimmer(vec2 uv, float time) {
    return sin(time + uv.x * 40.0 + uv.y * 40.0) * 0.012 + 0.988;
}
