#version 150

float fogValue(float dist, float fogStart, float fogEnd) {
    return clamp((dist - fogStart) / (fogEnd - fogStart), 0.0, 1.0);
}

vec3 toneMap(vec3 color) {
    return color / (color + vec3(1.0));
}

float luma(vec3 color) {
    return dot(color, vec3(0.2126, 0.7152, 0.0722));
}

vec3 saturate(vec3 color, float amount) {
    float l = luma(color);
    return mix(vec3(l), color, amount);
}

vec3 contrast(vec3 color, float amount) {
    return (color - 0.5) * amount + 0.5;
}

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
