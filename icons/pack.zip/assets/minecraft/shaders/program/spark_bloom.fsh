#version 150

uniform sampler2D DiffuseSampler;
uniform vec2 InSize;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

void main() {
    vec3 center = texture(DiffuseSampler, texCoord).rgb;
    float brightness = luma(center);
    if (brightness < 0.75) {
        fragColor = vec4(0.0);
        return;
    }
    vec3 bloom = center * (brightness - 0.75) * 0.4;
    fragColor = vec4(bloom, 1.0);
}
