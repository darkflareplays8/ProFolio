#version 150

uniform sampler2D DiffuseSampler;
uniform vec2 InSize;
uniform float Time;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 saturateColor(vec3 c, float a) { return mix(vec3(luma(c)), c, a); }
vec3 contrastColor(vec3 c, float a) { return clamp((c - 0.5) * a + 0.5, 0.0, 1.0); }

void main() {
    vec3 color = texture(DiffuseSampler, texCoord).rgb;

    vec2 uv = texCoord - 0.5;
    float vignette = 1.0 - dot(uv * vec2(1.2, 1.4), uv * vec2(1.2, 1.4)) * 1.6;
    vignette = clamp(vignette, 0.0, 1.0);
    vignette = pow(vignette, 0.45);
    color *= vignette;

    color = contrastColor(color, 1.06);
    color = saturateColor(color, 1.12);

    fragColor = vec4(color, 1.0);
}
