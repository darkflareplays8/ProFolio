#import <minecraft:include/spark_blocks.glsl>

uniform sampler2D u_BlockTex;
uniform sampler2D u_LightTex;
uniform float u_GameTime;

in vec2 v_TexCoord;
in vec4 v_Color;
in float v_FragDistance;

out vec4 fragColor;

void main() {
    vec4 texColor = texture(u_BlockTex, v_TexCoord);
    if (texColor.a < 0.1) discard;

    vec4 color = texColor * v_Color;
    float time = u_GameTime * 1200.0;

#ifdef RENDER_PASS_TRANSLUCENT
    color.rgb = spark_water(color.rgb, v_TexCoord, time);
    color.a *= 0.88;
#else
    color.rgb = spark_grade(color.rgb);
    color.rgb *= spark_shimmer(v_TexCoord, time);
#endif

    fragColor = color;
}
