#import <minecraft:include/chunk_vertex.glsl>

out vec2 v_TexCoord;
out vec4 v_Color;
out float v_FragDistance;

void main() {
    vec3 position = _vert_position;
    gl_Position = u_ProjectionMatrix * u_ModelViewMatrix * vec4(position, 1.0);

    v_TexCoord = _vert_tex_diffuse_coord;
    v_Color = _vert_color;
    v_FragDistance = length((u_ModelViewMatrix * vec4(position, 1.0)).xyz);
}
